/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Activity1.Tabel.Data.Tabel.Data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class DataKTP {
    
    public ArrayList<List<String>> datalengkap = new ArrayList<>();
}
